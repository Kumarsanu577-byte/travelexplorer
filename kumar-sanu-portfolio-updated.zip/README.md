# Kumar Sanu - Portfolio

A simple responsive personal portfolio website.

## Run locally
Open `index.html` in a web browser.

## Education
- 10th — Delhi Public School, Nawada, Bihar — 2023 — 88%
- 12th — Delhi Public School, Nawada, Bihar — 2025 — 84%
- B.Tech CSE — GLA University, Greater Noida — 2025-2029 — 2nd Year / 7.8 CGPA

## Run on GitHub Pages
1. Create a GitHub repository.
2. Upload `index.html`.
3. Go to **Settings → Pages**.
4. Select the branch containing `index.html`.
5. Save and open the generated GitHub Pages URL.

## Contact
Email: kumar.sanu_cs25@gla.ac.in
GitHub: https://github.com/Kumarsanu577-byte
